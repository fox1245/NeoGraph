#!/bin/sh
# NeoGraph release source-delivery recipe, 2026-10-05. MIT project license.
# The delivered sources already contain the documented library-only packaging patch.
set -eu
SOURCE_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
WORK=${1:?Usage: sh build-shared.sh NEW-ABSOLUTE-WORK-DIRECTORY [--qualification-markers]}
case "$WORK" in /*) ;; *) echo 'Work directory must be absolute' >&2; exit 2;; esac
if [ -e "$WORK" ]; then echo 'Choose a new work directory' >&2; exit 2; fi
case "$(uname -m)" in x86_64|aarch64) ;; *) echo 'Use native x86_64 or aarch64 Linux' >&2; exit 2;; esac
mkdir -p "$WORK/output"
cp -a "$SOURCE_ROOT/sources/keyutils-1.6.3" "$WORK/keyutils"
cp -a "$SOURCE_ROOT/sources/libxcrypt-4.4.18" "$WORK/libxcrypt"
(cd "$WORK/libxcrypt" && patch -p1 < "$SOURCE_ROOT/packaging/libxcrypt-4.4.17-enable_LTO_build.patch")
if [ "${2-}" = --qualification-markers ]; then
  (cd "$WORK/keyutils" && patch -p1 < "$SOURCE_ROOT/qualification/keyutils-marker.patch")
  (cd "$WORK/libxcrypt" && patch -p1 < "$SOURCE_ROOT/qualification/libxcrypt-marker.patch")
elif [ -n "${2-}" ]; then echo 'Unknown argument' >&2; exit 2; fi
(cd "$WORK/keyutils" && make libkeyutils.so.1.10 NO_ARLIB=1 NO_GLIBC_KEYERR=1 \
  VERSION=1.6.3 LIBDIR=/usr/lib64 USRLIBDIR=/usr/lib64 \
  CFLAGS='-Wall -O2 -g' LDFLAGS='-Wl,-z,relro -Wl,-z,now')
(cd "$WORK/libxcrypt" && sh ./autogen.sh && mkdir build && cd build && \
  ../configure --prefix=/usr --libdir=/usr/lib64 --with-pkgconfigdir=/usr/lib64/pkgconfig \
    --disable-failure-tokens --disable-silent-rules --enable-shared --enable-static \
    --enable-hashes=all --enable-obsolete-api=no --enable-obsolete-api-enosys=no \
    CFLAGS='-O2 -g' LDFLAGS='-Wl,-z,relro -Wl,-z,now' && make)
cp "$WORK/keyutils/libkeyutils.so.1.10" "$WORK/output/libkeyutils.so.1.10"
cp "$WORK/libxcrypt/build/.libs/libcrypt.so.2.0.0" "$WORK/output/libcrypt.so.2.0.0"
printf 'Architecture: %s\nLibraries: %s/output\n' "$(uname -m)" "$WORK"
