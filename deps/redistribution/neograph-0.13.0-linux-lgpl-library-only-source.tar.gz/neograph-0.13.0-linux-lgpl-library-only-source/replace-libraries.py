#!/usr/bin/env python3
"""Replace the two LGPL DSOs in one installed wheel, preserving repaired names.
NeoGraph release preparation, 2026-10-05; MIT (NeoGraph project license).
2026-10-05 candidate: compare complete public exports and ordered dependencies.
Source-only proposal; native ARM/x64 replacement/restoration is UNVERIFIED.
Run only in a disposable writable installation after stopping its processes.
The outer qualification gate owns source/mapping/hash checks and restoration.
"""
import hashlib
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys

libs, rebuilt = map(lambda x: Path(x).resolve(), sys.argv[1:3])
if libs.name != 'neograph_engine.libs':
    raise SystemExit('First argument must be installed neograph_engine.libs directory')
if shutil.which('patchelf') is None:
    raise SystemExit('patchelf is required in the qualification environment')


def inspect(path):
    data = path.read_bytes()
    if data[:6] != b'\x7fELF\x02\x01':
        raise SystemExit(f'Not an ELF64 little-endian library: {path}')
    dynamic = subprocess.check_output(['readelf', '-d', str(path)], text=True)
    symbols = subprocess.check_output(['readelf', '--dyn-syms', '--wide', str(path)], text=True)
    exports = set()
    for line in symbols.splitlines():
        fields = line.split()
        if len(fields) < 8 or not re.fullmatch(r'\d+:', fields[0]):
            continue
        # Match the outer gate: public definitions include data, weak/unique,
        # protected, unversioned and both single-/double-@ version spellings.
        if (fields[3] not in ('SECTION', 'FILE') and fields[4] in ('GLOBAL', 'WEAK', 'UNIQUE')
                and fields[5] in ('DEFAULT', 'PROTECTED') and fields[6] != 'UND'):
            exports.add(fields[7])
    floors = [tuple(map(int, value.split('.'))) for value in re.findall(r'@GLIBC_([0-9.]+)', symbols)]
    if any(value > (2, 34) for value in floors):
        raise SystemExit(f'GLIBC floor exceeds 2.34: {path}; observed {max(floors)}')
    match = re.search(r'\(SONAME\).*\[([^\]]+)\]', dynamic)
    if match is None:
        raise SystemExit(f'Missing SONAME: {path}')
    return {'machine': struct.unpack_from('<H', data, 18)[0], 'soname': match.group(1),
            'exports': exports, 'needed': re.findall(r'\(NEEDED\).*\[([^\]]+)\]', dynamic),
            'rpath': re.findall(r'\((?:RPATH|RUNPATH)\).*\[([^\]]*)\]', dynamic)}


# Derive names from actual installed files; never assume the old candidate hash.
for prefix, original, expected_soname in [('libkeyutils-', 'libkeyutils.so.1.10', 'libkeyutils.so.1'),
                                          ('libcrypt-', 'libcrypt.so.2.0.0', 'libcrypt.so.2')]:
    matches = list(libs.glob(prefix + '*.so.*'))
    if len(matches) != 1:
        raise SystemExit(f'Expected exactly one {prefix} library; got {matches}')
    old = matches[0]
    new = rebuilt / original
    old_info = inspect(old)
    new_info = inspect(new)
    if (old_info['machine'] != new_info['machine'] or old_info['exports'] != new_info['exports']
            or old_info['needed'] != new_info['needed'] or new_info['soname'] != expected_soname):
        raise SystemExit(f'Architecture/public ABI/ordered dependency/SONAME incompatible: {new}; '
                         f'missing {old_info["exports"] - new_info["exports"]}; '
                         f'added {new_info["exports"] - old_info["exports"]}; '
                         f'NEEDED {old_info["needed"]} -> {new_info["needed"]}')
    old_soname = old_info['soname']
    if old_soname != old.name:
        raise SystemExit(f'Recheck repair mapping: SONAME {old_soname} differs from filename {old.name}')
    backup = old.with_name(old.name + '.before-replacement')
    if backup.exists():
        raise SystemExit(f'Backup already exists: {backup}')
    staging = old.with_name(old.name + '.replacement')
    if staging.exists():
        raise SystemExit(f'Staging file already exists: {staging}')
    shutil.copyfile(new, staging)
    subprocess.check_call(['patchelf', '--set-soname', old_soname, '--force-rpath', '--set-rpath', '$ORIGIN', str(staging)])
    staged = inspect(staging)
    if (staged['machine'] != old_info['machine'] or staged['soname'] != old_soname
            or staged['exports'] != old_info['exports'] or staged['needed'] != old_info['needed']
            or staged['rpath'] != ['$ORIGIN']):
        raise SystemExit('Repaired replacement lost exact required ABI/dependencies/SONAME/RPATH')
    shutil.copyfile(old, backup)
    os.replace(staging, old)
    print(f'{old.name}: {hashlib.sha256(backup.read_bytes()).hexdigest()} -> {hashlib.sha256(old.read_bytes()).hexdigest()}')
    print('Preserved SONAME', staged['soname'], 'and all original public exports and ordered dependencies')
