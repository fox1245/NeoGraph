#!/usr/bin/env python3
"""Replace the two LGPL DSOs in one installed wheel, preserving repaired names.
NeoGraph release preparation, 2026-10-05; MIT (NeoGraph project license).
Run only in a disposable writable installation after stopping its processes.
"""
import hashlib
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys

libs, rebuilt = map(lambda x: Path(x).resolve(), sys.argv[1:3])
if libs.name != 'neograph_engine.libs':
    raise SystemExit('First argument must be installed neograph_engine.libs directory')
if shutil.which('patchelf') is None:
    raise SystemExit('patchelf is required in the qualification environment')

def inspect(path):
    data = path.read_bytes()
    if data[:6] != b'\x7fELF\x02\x01':
        raise SystemExit(f'Not an ELF64 little-endian library: {path}')
    dynamic = subprocess.check_output(['readelf', '-d', str(path)], text=True)
    symbols = subprocess.check_output(['readelf', '--dyn-syms', '--wide', str(path)], text=True)
    exports = set()
    for line in symbols.splitlines():
        match = re.search(r'\s(\w+@(?:@)?[\w.]+)(?:\s|$)', line)
        if match and ' UND ' not in line:
            exports.add(match.group(1))
    soname = re.search(r'\(SONAME\).*\[([^\]]+)\]', dynamic).group(1)
    return struct.unpack_from('<H', data, 18)[0], soname, exports

# Derive names from actual installed files; never assume the old candidate hash.
for prefix, original in [('libkeyutils-', 'libkeyutils.so.1.10'), ('libcrypt-', 'libcrypt.so.2.0.0')]:
    matches = list(libs.glob(prefix + '*.so.*'))
    if len(matches) != 1:
        raise SystemExit(f'Expected exactly one {prefix} library; got {matches}')
    old = matches[0]
    new = rebuilt / original
    old_machine, old_soname, old_exports = inspect(old)
    new_machine, _, new_exports = inspect(new)
    if old_machine != new_machine or not old_exports.issubset(new_exports):
        raise SystemExit(f'Architecture or versioned exports incompatible: {new}; missing {old_exports - new_exports}')
    if old_soname != old.name:
        raise SystemExit(f'Recheck repair mapping: SONAME {old_soname} differs from filename {old.name}')
    backup = old.with_name(old.name + '.before-replacement')
    if backup.exists():
        raise SystemExit(f'Backup already exists: {backup}')
    staging = old.with_name(old.name + '.replacement')
    shutil.copyfile(new, staging)
    subprocess.check_call(['patchelf', '--set-soname', old_soname, '--force-rpath', '--set-rpath', '$ORIGIN', str(staging)])
    machine, soname, exports = inspect(staging)
    if machine != old_machine or soname != old_soname or not old_exports.issubset(exports):
        raise SystemExit('Repaired replacement lost required ABI')
    shutil.copyfile(old, backup)
    os.replace(staging, old)
    print(f'{old.name}: {hashlib.sha256(backup.read_bytes()).hexdigest()} -> {hashlib.sha256(old.read_bytes()).hexdigest()}')
    print('Preserved SONAME', soname, 'and all original versioned exports')
