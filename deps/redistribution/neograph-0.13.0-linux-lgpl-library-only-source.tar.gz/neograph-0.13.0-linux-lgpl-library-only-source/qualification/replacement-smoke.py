#!/usr/bin/env python3
"""Parent/recipient runtime qualification. Not executed by source preparation.
NeoGraph release preparation, 2026-10-05; MIT (NeoGraph project license).
Usage: python replacement-smoke.py LIBS baseline|modified RESULT.json [BASELINE.json]
"""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import sys

libs = Path(sys.argv[1]).resolve()
mode = sys.argv[2]
if mode not in ('baseline', 'modified'):
    raise SystemExit('Expected baseline or modified mode')
# Import the actual installed engine first, without LD_LIBRARY_PATH/PRELOAD.
import neograph_engine

keyfile, = (p for p in libs.glob('libkeyutils-*.so.*') if not p.name.endswith(('.before-replacement', '.replacement')))
cryptfile, = (p for p in libs.glob('libcrypt-*.so.*') if not p.name.endswith(('.before-replacement', '.replacement')))
krbfile, = libs.glob('libkrb5-*.so.*')
key = ctypes.CDLL(str(keyfile), mode=os.RTLD_NOW, use_errno=True)
crypt = ctypes.CDLL(str(cryptfile), mode=os.RTLD_NOW, use_errno=True)
krb = ctypes.CDLL(str(krbfile), mode=os.RTLD_NOW, use_errno=True)
# Real exported informational marker; no application ABI is removed.
version = ctypes.string_at(ctypes.addressof(ctypes.c_char.in_dll(key, 'keyutils_version_string'))).decode()
assert ('NEOGRAPH-LGPL-REPLACEMENT' in version) == (mode == 'modified'), version
# Real password-hash operation through rebuilt libcrypt.
crypt.crypt.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
crypt.crypt.restype = ctypes.c_char_p
value = crypt.crypt(b'neograph-lgpl-recipient-smoke', b'$6$neograph-salt$')
assert value is not None and value.startswith(b'$6$neograph-salt$'), value
# Invalid ID: exercise wrapper without changing persistent kernel keyring state.
key.keyctl_get_keyring_ID.argtypes = [ctypes.c_int32, ctypes.c_int]
key.keyctl_get_keyring_ID.restype = ctypes.c_int32
ctypes.set_errno(0)
keyresult = key.keyctl_get_keyring_ID(-2147483647, 0)
keyerrno = ctypes.get_errno()
# Exercise a real dependent Kerberos library, without contacting a server.
context = ctypes.c_void_p()
krb.krb5_init_context.argtypes = [ctypes.POINTER(ctypes.c_void_p)]
krb.krb5_init_context.restype = ctypes.c_int32
krb.krb5_free_context.argtypes = [ctypes.c_void_p]
assert krb.krb5_init_context(ctypes.byref(context)) == 0
assert context.value is not None
krb.krb5_free_context(context)
mappings = Path('/proc/self/maps').read_text().splitlines()
loaded = sorted({line.split()[-1] for line in mappings if 'libkeyutils-' in line or '/libcrypt-' in line})
assert set(loaded) == {str(keyfile), str(cryptfile)}, loaded
result = {'mode': mode, 'libraryVersion': version, 'cryptHash': value.decode(),
          'keyctlResult': keyresult, 'keyctlErrno': keyerrno, 'mappedLibraries': loaded,
          'librarySHA256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (keyfile, cryptfile)}}
if mode == 'modified':
    baseline = json.loads(Path(sys.argv[4]).read_text())
    assert result['cryptHash'] == baseline['cryptHash']
    assert (keyresult, keyerrno) == (baseline['keyctlResult'], baseline['keyctlErrno'])
    assert result['librarySHA256'] != baseline['librarySHA256']
Path(sys.argv[3]).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
